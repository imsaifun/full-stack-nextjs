import React from 'react';
import Wrapper from '../components/auth/wrapper';

const Test = () => {
    return (
        <div>
            
            
                
           
           <Wrapper/>
        </div>
    );
};

export default Test;